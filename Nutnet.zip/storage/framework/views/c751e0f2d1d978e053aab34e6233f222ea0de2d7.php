<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">

                    <h1>Создание новой пластинки</h1>
                    <form method="POST" action="<?php echo e(route('DATA')); ?>" class="py-4">
                        <?php echo csrf_field(); ?>
                        <input name="name" placeholder="Название альбома" value="<?php echo e(old('name')); ?>" maxlength="255">
                        <input name="executor" placeholder="Группа/исполнитель"  value="<?php echo e(old('executor')); ?>" maxlength="255">
                        <input name="description" placeholder="Описание"  value="<?php echo e(old('description')); ?>" maxlength="255">
                        <input name="img_link" placeholder="Ссылка на обложку (URL картинки)"  value="<?php echo e(old('img_link')); ?>" maxlength="255">

                        <button type="submit">Сохранить новый альбом</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\Nutnet\resources\views/newalbum.blade.php ENDPATH**/ ?>