<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">

                    <h1>Список всех альбомов</h1>
                    <div class="container" id="container_main">
                            <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $string): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php if($id ==$string->id_album): ?>
                                        <div class="album__container">
                                            <p><?php echo e($string->name); ?></p>
                                            <p><?php echo e($string->executor); ?></p>
                                            <p><?php echo e($string->description); ?></p>
                                            <img src="<?php echo e($string->img_link); ?>" alt="error" width="250px" height="250px">

                                            <form method="get" action="<?php echo e(route('album',[$id])); ?>" >
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="but">Подробнее</button>
                                            </form>
                                        </div>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\Nutnet\resources\views/index.blade.php ENDPATH**/ ?>