<?php

namespace App\Http\Controllers;
namespace App\Models;

use Illuminate\Http\Request;
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Log;

class WebController extends Controller
{
    public function albums()
    {
        $albums = DB::table('album')->get();
        $album = DB::table('album')->where('id_album')->first();
        foreach ($albums as $string) {
            $array[] = $string->id_album;
        }
        //return view('index', ['array' => $array]);

        //dd($id);
        //dd($album);
        return view('index', [
            'albums' => $albums,
            'name' => $string->name,
            'executor' => $string->executor,
            'description' => $string->description,
            'img_link' => $string->img_link,
            'id' => $string->id_album,
            'array' => $array,
        ]);
    }

    public function album($id) {
        $album = DB::table('album')->where('id_album', '=', $id)->first();
        //dd($album->executor);
        //dd($album);
        //dd($id);

        return view('album', [
            'name' => $album->name,
            'executor' => $album->executor,
            'description' => $album->description,
            'img_link' => $album->img_link,
            'id'=>$id,
        ]);
    }

    public function change($id) {
        $album = DB::table('album')->where('id_album', '=', $id)->first();
        $id = DB::table('album')->where('id_album', '=', $id)->first();
        //dd($id);

        return view('index', [
            'id'=>$id,
        ]);
    }

    public function delete($id) {
        $album = DB::table('album')->where('id_album', '=', $id)->first();
        //dd($id);
        $album = DB::table('album')->where('id_album', '=', $id)->first();

        DB::table('album')
            ->where('id_album', $id)
            ->delete();
        //dd($id2);
        return redirect('/');
    }


        public function DATA(Request $request){
            //dd($request->map_link);
            if (trim($request->name) === '')
                die('Может быть вы введете информацию? Ну хотябы что-то...');
            elseif (trim($request->executor) === '')
                die('О нет! Это надо заполнить! Обязательно!');
            elseif (trim($request->description) === '')
                die('Маловато будет...');
            elseif (trim($request->img_link) === '')
                die('Вы почти справились с заполнением ВСЕХ полей! Но что-то пошло не так...');
            DB::table('album')->insert([
                'name' => $request->name,
                'executor' => $request->executor,
                'description' => $request->description,
                'img_link' => $request->img_link,
            ]);
            log::info('Название: '.$request->name);
            log::info('Группа: '.$request->executor);
            log::info('Описание: '.$request->description);
            log::info('Ссылка: '.$request->img_link);
            return redirect('/');
        }

        public function changing(Request $request){
            $name = $request->input('name');
            $executor = $request->input('executor');
            $description = $request->input('description');
            $img_link = $request->input('img_link');
            $id = $request->input('id');
            //dd($id);
            if (trim($name) === '')
                die('Может быть вы введете информацию? Ну хотябы что-то...');
            //dd($request->name);
            elseif (trim($executor) === '')
                die('О нет! Это надо заполнить! Обязательно!');
            elseif (trim($description) === '')
                die('Маловато будет...');
            elseif (trim($img_link) === '')
                die('Вы почти справились с заполнением ВСЕХ полей! Но что-то пошло не так...');
            //dd($request->description);
            DB::table('album')->where('id_album', '=', $request->id)->update([
                'name' => $request->name,
                'executor' => $request->executor,
                'description' => $request->description,
                'img_link' => $request->img_link,
            ]);
            log::info('Название изменено на: '.$name);
            log::info('Группа измененa на: '.$executor);
            log::info('Описание измененo на: '.$description);
            log::info('Ссылка измененa на: '.$img_link);
            return redirect('/album/'.$id);
        }

}
