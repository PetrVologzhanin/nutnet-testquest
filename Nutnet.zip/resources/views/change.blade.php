@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">

                    <h1>Изменение/добавление/удаление альбома!</h1>
                    <div class="container" id="container_main">
                        <div class="album__container">
                            <p>{{ $name}}</p>
                            <p>{{ $executor }}</p>
                            <p>{{ $description }}</p>
                            <img src="{{ $img_link }}" width="250px" height="250px">
                            <form method="get" action="{{route('delete',['id'=>$id])}}">
                                @csrf
                                <button type="submit" class="but">Изменить альбом</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
