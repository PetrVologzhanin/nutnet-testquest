<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">

                    <h1>Изменение/удаление альбома!</h1>
                        <div class="container" id="container_main">
                            <div class="album__container">
                                <p><?php echo e($name); ?></p>
                                <p><?php echo e($executor); ?></p>
                                <p><?php echo e($description); ?></p>
                                <img src="<?php echo e($img_link); ?>" width="250px" height="250px">
                                <form method="get" action="<?php echo e(route('delete',['id'=>$id])); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="but">Удалить альбом</button>
                                </form>
                            </div>

                            <form action="<?php echo e(route('changing')); ?>" class="py-4" method="post" id="top">
                                <?php echo csrf_field(); ?>

                                        <input type="text" name="name" value="<?php echo e($name); ?>" maxlength="255">
                                        <input type="text" name="executor" value="<?php echo e($executor); ?>" maxlength="255">
                                        <input type="text" name="description" value="<?php echo e($description); ?>" maxlength="255">
                                        <input type="text" name="img_link" value="<?php echo e($img_link); ?>" maxlength="255">
                                        <input type="hidden" name="id" value="<?php echo e($id); ?>" maxlength="255" id="none">
                                <button type="submit" class="but">Сохранить изменения</button>
                            </form>
                        </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\Nutnet\resources\views/album.blade.php ENDPATH**/ ?>