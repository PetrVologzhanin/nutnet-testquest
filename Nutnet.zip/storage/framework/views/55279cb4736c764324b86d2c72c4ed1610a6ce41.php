<?php echo e($slot); ?>

<?php /**PATH C:\OSPanel\domains\Nutnet\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>