@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">

                    <h1>Список всех альбомов</h1>
                    <div class="container" id="container_main">
                            @foreach ($albums as $string)
                                @foreach($array as $id)

                                @if ($id ==$string->id_album)
                                        <div class="album__container">
                                            <p>{{ $string->name}}</p>
                                            <p>{{ $string->executor }}</p>
                                            <p>{{ $string->description }}</p>
                                            <img src="{{ $string->img_link }}" alt="error" width="250px" height="250px">

                                            <form method="get" action="{{route('album',[$id])}}" >
                                                @csrf
                                                <button type="submit" class="but">Подробнее</button>
                                            </form>
                                        </div>
                                @endif
                                @endforeach
                            @endforeach
                    </div>

                </div>
            </div>
        </div>
    </div>
@endsection
