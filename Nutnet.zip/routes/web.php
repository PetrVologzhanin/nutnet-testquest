<?php

use Illuminate\Support\Facades\Route;

Route::get('/home', function () {
    return view('index');
});

Auth::routes();

Route::get('/home', function () {
    return view('index');
});

Route::get('/addalbum/{id}', function () {
    return view('/');
});

Route::get('/newalbum', function () {
    return view('newalbum');
});


Route::get('/index', [App\Http\Controllers\HomeController::class, 'index'])->name('index');
Route::get('/', [App\Http\Controllers\WebController::class, 'albums'])->name('albums');
Route::get('/album/{id}', [\App\Http\Controllers\WebController::class, 'album'])->middleware('auth')->name('album');
//Route::get('/album/{id}', [\App\Http\Controllers\WebController::class, 'change'])->name('change');
Route::get('/addalbum/{id}', [\App\Http\Controllers\WebController::class, 'delete'])->name('delete');
Route::post('/test', [App\Http\Controllers\WebController::class, 'DATA'])->name('DATA');
Route::get('/testlog', [App\Http\Controllers\WebController::class, 'testlog'])->name('testlog');
Route::post('/test2', [App\Http\Controllers\WebController::class, 'changing'])->name('changing');
//Route::get('/album/{id}', [App\Http\Controllers\WebController::class, 'change'])->name('change');
